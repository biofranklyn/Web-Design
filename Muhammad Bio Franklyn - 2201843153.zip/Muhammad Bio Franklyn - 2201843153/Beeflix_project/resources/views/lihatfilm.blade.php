@extends('layout/header')

@section('style')
    <style>

        .boxoutside{
            background-color: #929292;
            width: 97%;
            height: auto;
            display: flex;
            flex-direction: column;
        }
        .boxinside{
            background-color: white;
            width: 90% !important;
            height: 500px;
        }

        .movie{
            max-width: 200px;
            margin-top: 10px;
            display: inline-block;
        }
        
        .imagemovie{
            max-width: 200px;
            max-height: 280px;
        }
        
        .category{
            display: inline-block;
            vertical-align: top;
        }

        .paragraph{
            margin-left: 10px;
            display: inline-block;
            vertical-align: top;
        }
        .desc{
            margin-top: 30px;
            margin-left: 5px;
            display: inline-block;
            max-width: 400px;
            font-size: 15px;
            text-align: justify;
        }

        .categ{
            font-size: 14px;
        }
        .episode{
            display: inline-block;
            vertical-align: top;
        }
        .tableepisode{
            font-family: 'Georgia';
            border-collapse: collapse;
            width: 100%;
            vertical-align: top;
            margin-left: 100px;
        }
        table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
        }

        tr:nth-child(even) {
        background-color: #dddddd;
        }

        .scrolltable{
            margin-left: 100px;
            border: #929292
        }
    </style>
    
    @section('containers')
        <div class="containers">
            <div class="col boxoutside mx-auto">
                <div class="row boxinside my-5 mx-auto">
                    <div class="col category">
                            <div class="movie text-center">
                                <img class="imagemovie" src="{{ asset('image/'.$movies->photo) }}" alt="start-up"> 
                            </div>
                            <div class="paragraph">
                                <h2 class="movieTitle">{{$movies->title}}</h2>
                                <h4 class="movierating">&#9733;&#9733;&#9733;&#9733;&#9733;</h4>
                                <div class="desc">
                                    <p class="genreTitle">{{$movies->description}}</p>
                                    <p class="categ">
                                    Category : <a href="/genre/{{$movies->genre_id}}">{{$movies->Genre->name}}</a>
                                    </p>
                                </div>
                            </div>
                            <div class="episode">
                                <table class="tableepisode">
                                    <tr>
                                      <th>Episode</th>
                                      <th>Judul</th>
                                    </tr>
                                    @foreach ($episodes as $item)
                                    <tr>
                                        <td>Episode {{$item->episode}}</td>
                                        <td>{{$item->title}}</td>
                                      </tr>
                                    @endforeach
                                </table>
                                  <div class="scrolltable">
                                      {{$episodes->Links()}}
                                  </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        
    @endsection
@endsection