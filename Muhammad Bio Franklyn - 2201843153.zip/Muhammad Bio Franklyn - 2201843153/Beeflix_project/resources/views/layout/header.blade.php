<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    
    <link rel="stylesheet" href="{{ asset ('bootstrap/css/bootstrap.min.css')}}">
    <script src="{{ asset ('bootstrap/js/bootstrap.min.js')}}"></script>

    <style>
        body{
            background-color: aliceblue;
            font-family: 'Georgia';
        }
        .navbar{
           display: block;
        }   
        .navbar-nav {
           display: flex;
           flex-direction: row;
        }
        .navbar-menu li{
            display: inline-block !important;
            margin: 0;
        }
       .beeflix{
           display: block;
           margin: 0 0 5px;

        }
        .kembali{
            color: white;
            background-color: #2b2922;
            padding: 10px 10px;
            vertical-align: middle;
        }
        .kembali>a{
            color: white;
            text-decoration: none;
        }
        .semuamovies{
            padding: 2px 10px;
            border: 1px solid #2b2922;
        }
        .kembali:hover{
            cursor: pointer;
            background-color: aquamarine;
            color: black
        }
        .semuamovies:hover{
            cursor: pointer;
            background-color: green;
            color: white;
        }
        .brand-name:hover{
            cursor: pointer;
        }
        .btn{
            color: #2b2922;
        }
    </style>
    @yield('style')
</head>

<body>
    <nav class="navbar">
        <h1 class="beeflix">BeeFlix</h1>
        <ul class="navbar-nav">
            <li>
                <div class="kembali">
                    <a href="javascript:history.back()">
                    <span>
                        <span style="font-size: 14px">
                            &#11013;
                        </span>KEMBALI</span>
                    </a>
                </div>
            </li>
            <li>
                <div class="semuamovies ml-0">
                    <span><a href="/" class="btn">LIHAT SEMUA FILM</a></span>
                </div>
            </li>
        </ul>
    </nav>
    @yield('containers')
</body>
</html>


