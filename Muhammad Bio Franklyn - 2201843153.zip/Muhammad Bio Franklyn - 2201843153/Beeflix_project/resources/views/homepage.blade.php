@extends('layout/header')

@section('style')
    <style>

        .boxoutside{
            background-color: #929292;
            width: 97%;
            height: auto;
            display: flex;
            flex-direction: column;
        }
        .boxinside{
            background-color: white;
            width: 90% !important;
            height: auto;
        }

        .movie{
            max-width: 200px;
        }
        
        .imagemovie{
            max-width: 200px;
            max-height: 280px;
        }

        .listfilm{
            display: flex;
            justify-content: space-evenly;
        }

    </style>
    
    @section('containers')
        <div class="containers">
            <div class="col boxoutside mx-auto">
                <div class="row boxinside my-5 mx-auto">
                    <div class="col category">
                        @foreach ($genres as $genre)
                            <div class="row ml-2">
                            <h1>{{$genre->name}}</h1>
                            </div>
                            <div class="row mx-0 px-0 listfilm">
                                @foreach ($movies as $movie)
                                    @if ($movie->genre_id == $genre->id)
                                    <div class="movie text-center">
                                        <img class="imagemovie" src="{{ asset('image/'.$movie->photo) }}" alt="start-up"> 
                                        <span class="movieTitle">{{$movie->title}}</span>
                                        <form action="/detail/{{$movie->id}}" method="GET">
                                        <input type="submit" class="btn btn-danger outline" value="Lihat Film">
                                    </form>    
                                    </div>
                                    @endif
                                @endforeach
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
        
    @endsection
@endsection