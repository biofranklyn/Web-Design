<?php

use Illuminate\Database\Seeder;

class EpisodeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
            DB::table('episodes')->insert([
            
                'movies_id'=>'1',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'2',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'3',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'4',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'1',
                'title'=>'START-UP'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'2',
                'title'=>'FAMILY,FRIENDS,FOOLS'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'3',
                'title'=>'ANGEL'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'4',
                'title'=>'SANDBOX'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'5',
                'title'=>'HACKATHON'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'6',
                'title'=>'KEY MAN'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'7',
                'title'=>'BRUN RATE'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'5',
                'episode'=>'8',
                'title'=>'BACKUP'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'1',
                'title'=>'HYUNG'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'2',
                'title'=>'GREET GOD'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'3',
                'title'=>'THE LONELY'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'4',
                'title'=>'CHEMISTRY'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'5',
                'title'=>'LEE DONG'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'6',
                'title'=>'KEMAN'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'7',
                'title'=>'RATE'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'6',
                'episode'=>'8',
                'title'=>'THE LADY'
             
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'1',
                'title'=>'THE BOY WHO'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'2',
                'title'=>'THE LADY'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'3',
                'title'=>'RED SHOES'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'4',
                'title'=>'ZOMBIE KID'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'5',
                'title'=>'RAPUNZEL'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'6',
                'title'=>'CHEERFUL'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'7',
                'title'=>'THE BEAST'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'7',
                'episode'=>'8',
                'title'=>'LADY BOY'
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'8',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'9',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'10',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'11',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
            DB::table('episodes')->insert([
            
                'movies_id'=>'12',
                'episode'=>'1',
                'title'=>'Film'
            
            ]);
    }
}
