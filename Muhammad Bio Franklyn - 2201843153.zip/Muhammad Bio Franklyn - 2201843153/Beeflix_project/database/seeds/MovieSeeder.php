<?php

use Illuminate\Database\Seeder;

class MovieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('movies')->insert([
            [
                'genre_id'=>'1',
                'title'=>'Final Girl',
                'photo'=>'finalgirl.jpg',
                'description'=>'film Amerika Serikat tahun 2015 bergenre thriller aksi horor yang disutradarai oleh Tyler Shields sebagai debut penyutradaraannya, berdasarkan skenario yang disusun oleh Adam Prince, mengangkat cerita karya Stephen Scarlata, Alejandro Seri, dan Johnny Silver.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'1',
                'title'=>'Supergirl',
                'photo'=>'supergirl.jpg',
                'description'=>'Supergirl adalah sepupu dari kal-el atau yang akan menjadi superman. Ceritanya adalah ketika planet krypton akan hancur kal-el diluncurkan oleh orang tuanya ke bumi, namun ia tak sendirian, orang tua kal-el juga melarikan seorang gadis kecil yang merupakan sepupu dari kal-el bernama Kara (Malina Weissman).',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'1',
                'title'=>'Burn Out',
                'photo'=>'burnout.jpg',
                'description'=>'Burnout ini menceritakan tentang pelarian seseorang terhadap masalah-masalah pribadinya yang hanya ada didalam pikirannya. Membangun motivasi diri untuk menghadai masalah ayng ada menjadi tujuan dalam film animasi Burnout ini.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'1',
                'title'=>'Headshot',
                'photo'=>'headshot.jpg',
                'description'=>'Headshot mengisahkan tentang pria yang menderita amnesia dengan masa lalu yang misterius. Ia kemudian menjadi (mesin pembunuh) yang mematikan saat harus berhadapan dengan seorang gembong narkoba yang sangat berbahaya.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'2',
                'title'=>'StartUp',
                'photo'=>'start-up.jpg',
                'description'=>'Start-Up berkisah tentang kehidupan percintaan hingga karier para remaja yang bermimpi untuk sukses di dunia perusahaan startup. Termasuk, Seo Dal Mi (Bae Suzy) dan Nam Do San (Nam Joo Hyuk). Drama ini diperankan para bintang papan atas, di antaranya Nam Joo Hyuk, Bae Suzy, Kim Seon Ho dan Kang Han Na.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'2',
                'title'=>'Goblin',
                'photo'=>'goblin.jpg',
                'description'=>'Drama Korea Goblin berkisah tentang Jenderal Kim Shin yang dikutuk menjalani kehidupan abadi di bumi sebagai seorang Goblin. Korea Selatan di era Dinasti Goryeo, seorang jenderal bernama Kim Shin ( Gong Yoo) dituduh berkhianat oleh Raja Muda (Kim Min Jae) yang iri dengan keberhasilannya.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'2',
                'title'=>'Its Okey to Not Be Okey',
                'photo'=>'itsokeytonotbeokay.jpg',
                'description'=>'Drama ini menceritakan hubungan asmara tidak biasa antara dua orang yang akhirnya saling menyembuhkan luka emosional dan psikologis satu sama lain.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'2',
                'title'=>'Moonlight',
                'photo'=>'moonlight.jpg',
                'description'=>'Drama semi otobiografi tentang tiga plot kehidupan pria kulit hitam yang menyinggung tema LGBTQ. Dirilis tahun 2016, film ini disutradarai oleh Barry Jenkins dan diangkat dari drama "In Moonlight Black Boys Look Blue" kaya Tarell Alvin McCraney.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'3',
                'title'=>'Cars 3',
                'photo'=>'cars3.jpg',
                'description'=>'Cars 3 bercerita tentang perjalanan Lightning McQueen (Owen Wilson) yang terancam oleh kehadiran pembalap generasi baru bernama Jackson Strom (Armie Hammer). Setelah banyaknya kekalahan dan juga ditambah kecelakaan fatal yang berujung dramatis, McQueen harus instropeksi diri.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'3',
                'title'=>'Coco',
                'photo'=>'disneycoco.jpg',
                'description'=>'Coco mengikuti kisah Miguel Rivera (Anthony Gonzalez), seorang anak berusia 12 tahun yang tinggal bersama neneknya bernama Mama Coco (Ana Ofelia Murguia). Mereka tinggal di sebuah desa kecil di Meksiko. Saat Mama Coco kecil, ia tinggal bersama sang ibu, Mama Imelda Rivera (Alanna Ubach).',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'3',
                'title'=>'Spongebob the Movie',
                'photo'=>'spongebobmovie.jpg',
                'description'=>'SpongeBob SquarePants adalah sebuah serial animasi yang paling terpopuler di Nickelodeon. Pada awalnya serial kartun animasi ini ditayangkan pada tahun 1999 di Amerika Serikat dan dicipta oleh Stephen Hillenburg, seorang animator dan ahli biologi laut, dan diterbitkan oleh perusahaannya, United Plankton Pictures Inc.',
                'rating'=>'5'
            ],
            [
                'genre_id'=>'3',
                'title'=>'Onward',
                'photo'=>'disneyonward.jpg',
                'description'=>'Set in a suburban fantasy world, the film follows two elf brothers who set out on a quest to find an artifact that will temporarily bring back their deceased father. ',
                'rating'=>'5'
            ]
        ]);
    }
}
