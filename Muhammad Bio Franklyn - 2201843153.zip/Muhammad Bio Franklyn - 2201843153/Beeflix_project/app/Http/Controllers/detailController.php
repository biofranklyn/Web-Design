<?php

namespace App\Http\Controllers;
use App\Genre;
use App\Movie;
use Illuminate\Http\Request;

class detailController extends Controller
{
    function goGenre($id){
        $genres = Genre::where('id',$id)->first();
        $movies = Movie::where('genre_id',$id)->get();
        return view('categories',['movies'=>$movies,'genres'=>$genres]);
    }
}
