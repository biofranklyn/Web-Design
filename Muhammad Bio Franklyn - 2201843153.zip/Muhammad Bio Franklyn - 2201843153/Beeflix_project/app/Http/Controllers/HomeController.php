<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Movie;
use App\Genre;
use App\Episode;

class HomeController extends Controller
{


    function page(){
        $movies = Movie::all();
        $genres = Genre::all();
        return view('homepage',['movies'=>$movies, 'genres'=>$genres]);
    }

    function detail($id){
        $movies = Movie::where('id', $id)->first();
        $episodes = Episode::where('movies_id', $id)->paginate(3);
        return view('lihatfilm',['movies'=>$movies, 'episodes'=>$episodes]);
    }
}
