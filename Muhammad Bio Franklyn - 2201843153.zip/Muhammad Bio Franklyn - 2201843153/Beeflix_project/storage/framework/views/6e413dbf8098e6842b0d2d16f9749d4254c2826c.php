

<?php $__env->startSection('style'); ?>
    <style>

        .boxoutside{
            background-color: #929292;
            width: 97%;
            height: auto;
            display: flex;
            flex-direction: column;
        }
        .boxinside{
            background-color: white;
            width: 90% !important;
            height: 500px;
        }

        .movie{
            max-width: 200px;
            margin-top: 10px;
            display: inline-block;
        }
        
        .imagemovie{
            max-width: 200px;
            max-height: 280px;
        }
        
        .category{
            display: inline-block;
            vertical-align: top;
        }

        .paragraph{
            margin-left: 10px;
            display: inline-block;
            vertical-align: top;
        }
        .desc{
            margin-top: 30px;
            margin-left: 5px;
            display: inline-block;
            max-width: 400px;
            font-size: 15px;
            text-align: justify;
        }

        .categ{
            font-size: 14px;
        }
        .episode{
            display: inline-block;
            vertical-align: top;
        }
        .tableepisode{
            font-family: 'Georgia';
            border-collapse: collapse;
            width: 100%;
            vertical-align: top;
            margin-left: 100px;
        }
        table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
        }

        tr:nth-child(even) {
        background-color: #dddddd;
        }

        .scrolltable{
            margin-left: 100px;
            border: #929292
        }
    </style>
    
    <?php $__env->startSection('containers'); ?>
        <div class="containers">
            <div class="col boxoutside mx-auto">
                <div class="row boxinside my-5 mx-auto">
                    <div class="col category">
                            <div class="movie text-center">
                                <img class="imagemovie" src="<?php echo e(asset('image/'.$movies->photo)); ?>" alt="start-up"> 
                            </div>
                            <div class="paragraph">
                                <h2 class="movieTitle"><?php echo e($movies->title); ?></h2>
                                <h4 class="movierating">&#9733;&#9733;&#9733;&#9733;&#9733;</h4>
                                <div class="desc">
                                    <p class="genreTitle"><?php echo e($movies->description); ?></p>
                                    <p class="categ">
                                    Category : <a href="/genre/<?php echo e($movies->genre_id); ?>"><?php echo e($movies->Genre->name); ?></a>
                                    </p>
                                </div>
                            </div>
                            <div class="episode">
                                <table class="tableepisode">
                                    <tr>
                                      <th>Episode</th>
                                      <th>Judul</th>
                                    </tr>
                                    <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>Episode <?php echo e($item->episode); ?></td>
                                        <td><?php echo e($item->title); ?></td>
                                      </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                                  <div class="scrolltable">
                                      <?php echo e($episodes->Links()); ?>

                                  </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas Semester 5\netflix kw\Beeflix_project\resources\views/lihatfilm.blade.php ENDPATH**/ ?>