

<?php $__env->startSection('style'); ?>
    <style>
        .boxoutside{
            background-color: #929292;
            margin: 15px auto;
            width: 97%;
            height: 1200px;
            position: relative;
        }
    
        .boxinside{
            background-color: white;
            position: absolute;
            top: 10%;
            left: 1.5%;
            width: inherit;
            height: 1000px;
        }
        .category{
            margin: 10px 50px;
        }
        .movie{
            max-height: 200px;
            margin: 0px auto;
            text-align: center;
            max-width: 200px;
            display: inline-block;
            border: 1px solid rgb(248, 243, 243)
        }
        .imagemovie{
            max-width: 200px;
            max-height: 280px;
        }
        .viewmovie{
            width: 100%;
            background-color: #4e4f4d;
            color: white;
            border-radius: 5px;
            padding: 3px 0;
        }
        .listfilm{
            position: relative;
            width: 70%;
            height: auto;
            margin: auto;
            padding-bottom: 10px;
        }
    </style>
    
    <?php $__env->startSection('containers'); ?>
        <div class="containers">
            <div class="boxoutside">
                <div class="boxinside">
                    <div class="category">
                        <h1><?php echo e($genres->name); ?></h1>
                        <div class="listfilm">
                            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="movie">
                                <img class="imagemovie" src="<?php echo e(asset('image/'.$movie->photo)); ?>" alt="start-up"> 
                                <p class="movieTitle"><?php echo e($movie->title); ?></p>
                                <form action="/detail/<?php echo e($movie->id); ?>" method="GET">
                                <input type="submit" class="btn btn-danger outline" value="Lihat Film">
                                </form>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas Semester 5\netflix kw\Beeflix_project\resources\views/categories.blade.php ENDPATH**/ ?>