

<?php $__env->startSection('style'); ?>
    <style>

        .boxoutside{
            background-color: #929292;
            width: 97%;
            height: auto;
            display: flex;
            flex-direction: column;
        }
        .boxinside{
            background-color: white;
            width: 90% !important;
            height: auto;
        }

        .movie{
            max-width: 200px;
        }
        
        .imagemovie{
            max-width: 200px;
            max-height: 280px;
        }

        .listfilm{
            display: flex;
            justify-content: space-evenly;
        }

    </style>
    
    <?php $__env->startSection('containers'); ?>
        <div class="containers">
            <div class="col boxoutside mx-auto">
                <div class="row boxinside my-5 mx-auto">
                    <div class="col category">
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row ml-2">
                            <h1><?php echo e($genre->name); ?></h1>
                            </div>
                            <div class="row mx-0 px-0 listfilm">
                                <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($movie->genre_id == $genre->id): ?>
                                    <div class="movie text-center">
                                        <img class="imagemovie" src="<?php echo e(asset('image/'.$movie->photo)); ?>" alt="start-up"> 
                                        <span class="movieTitle"><?php echo e($movie->title); ?></span>
                                        <form action="/detail/<?php echo e($movie->id); ?>" method="GET">
                                        <input type="submit" class="btn btn-danger outline" value="Lihat Film">
                                    </form>    
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tugas Semester 5\netflix kw\Beeflix_project\resources\views/homepage.blade.php ENDPATH**/ ?>