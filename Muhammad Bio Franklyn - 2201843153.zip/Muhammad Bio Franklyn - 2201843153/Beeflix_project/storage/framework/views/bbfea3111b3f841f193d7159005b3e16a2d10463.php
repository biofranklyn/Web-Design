<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="../../bootstrap">
    <script src="../../bootstrap/js/bootstrap.js"></script>

    <style>
        .body{
            background-color: aliceblue;
            font-family: 'Georgia';
        }
        .navbar{
            width: 97%;
            height: 70%;
            margin: 0 auto;
        }
        .navbar-menu {
            list-style-type: none;
            display:inline-block;
            padding-left: 0;
            margin: 0;
        }
        .navbar-menu li{
            display: inline-block !important;
            margin: 0;
        }
       .brand-name{
           display: block;
           margin: 0 0 5px;
        }
        .kembali{
            color: white;
            background-color: #2b2922;
            padding: 3px 10px;
            vertical-align: middle;
        }
        .semuamovies{
            padding: 2px 10px;
            border: 1px solid #2b2922;
            margin-left: -5px;
        }
        .kembali:hover{
            cursor: pointer;
            background-color: aquamarine;
            color: black
        }
        .semuamovies:hover{
            cursor: pointer;
            background-color: green;
            color: white;
        }
        .brand-name:hover{
            cursor: pointer;
        }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <nav class="navabar">
        <h1 class="brand-nama">BeeFlix</h1>
        <ul class="navbar-menu">
            <li>
                <div class="back">
                    <span>
                        <span style="font-size: 14px">
                            &#11013;
                        </span>Kembali</span>
                </div>
            </li>
            <li>
                <div class="allmovies">
                    <span>Lihat semua film</span>
                </div>
            </li>
        </ul>
    </nav>
    <?php echo $__env->yieldContent('containers'); ?>
</body>
</html><?php /**PATH D:\tugas Semester 5\netflix kw\Beeflix_project\resources\views/layout/general.blade.php ENDPATH**/ ?>